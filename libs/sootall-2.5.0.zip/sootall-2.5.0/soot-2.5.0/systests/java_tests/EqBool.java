public class EqBool {

    public static void main(String [] args){
        boolean b1 = true;
        boolean b2 = true;
        if (b1 == b2){
            
        }
    }
}
