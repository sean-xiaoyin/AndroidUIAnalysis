public class StringTest1 {
    public static void main(String [] args){
        String s = "t" + "h" + "e" + "r"+ "e";
        System.out.println(s);
    }
}
