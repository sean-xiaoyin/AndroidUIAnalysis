import java.util.*;
public class NullTest {

    public static void main( String [] args) {
    
        ArrayList i = null;
        ArrayList j = null;
        
        if (i == null & j == null) {
            i = new ArrayList();
        }
    }
}
