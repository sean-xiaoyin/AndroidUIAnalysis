public class StringConcatCond {

    public static void main(String [] args){
        int x = 9;
        int y = 2;
        System.out.println("hello"+(x>y));
    }
}
