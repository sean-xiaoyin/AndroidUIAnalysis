public class CondTest2 {

    public static void main(String [] args){
        int i = 1;
        do {
            if (i == 1) break;
            i = i + 1;
            i++;
            i++;
            i++;
            i--;
            i++;
        }while(true);
    }
}
