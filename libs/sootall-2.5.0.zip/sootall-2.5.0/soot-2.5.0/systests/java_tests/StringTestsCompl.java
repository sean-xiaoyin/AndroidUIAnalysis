public class StringTestsCompl{

    public static void main (String [] args) {
    
            int i = 0;
            System.out.println("Smile");
            i += i;
            System.out.println("Number: "+i);
            i += i;
            System.out.println(i);
            System.out.println('c'+'h');

            java.util.Iterator it = null;
            System.out.println("Iterator: "+it);
    }
    
}
