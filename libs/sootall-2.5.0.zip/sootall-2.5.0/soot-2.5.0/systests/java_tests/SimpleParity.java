public class SimpleParity {


    public static void main(String [] args){
    
        int i = 9;
        int j = 8;

        int k = 0;
        
        for (int h = 0; h < 10; h++){
            k = k + j;
        }
        
    }
}
