public class LHSTest {
    
    int x;
    
    public static void main(String [] args) {
   
        LHSTest l = new LHSTest();
        l.run();
    }

    private void run(){
        int i = 0;
        int j = 9;

        int k = 4;

        x = j;
        System.out.println(x);
    }
}
