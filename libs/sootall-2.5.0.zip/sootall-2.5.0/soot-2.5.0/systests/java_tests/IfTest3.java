public class IfTest3 {

    public static void main(String [] args){
        int i = 9;
        int j = 5;
        
        if (i < 10) {
            j++;    
        }
        else {
            j--;
        }
    }
}
