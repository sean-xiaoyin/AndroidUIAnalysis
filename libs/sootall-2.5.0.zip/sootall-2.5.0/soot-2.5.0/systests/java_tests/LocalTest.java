public class LocalTest {

    public static void main(String [] args){
        LocalTest lt = new LocalTest();
        lt.run();
    }
    
    public void run(){
        int i = 0;
        i++;
    }
}
