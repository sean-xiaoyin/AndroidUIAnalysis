class OtherClass{
    public static void run(){
    }
}
public class StaticMethodOtherClass {

    public static void main(String [] args){
    
        OtherClass.run();
    }
}
