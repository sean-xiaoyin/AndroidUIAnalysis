public class PrimTest {
    
    public static void main(String [] args){
        char c = 'g';
        byte b = 2;
        boolean l = true;
        short s = 3;
        System.out.println(c);
        System.out.println(b);
        System.out.println(l);
        System.out.println(s);
    }
}
