public class LoopTest3 {

    public static void main(String [] args){
    
        int [][] x = new int [10][10];
        for (int i = 0; i < 10; i++){
            for (int j = 0; j < 10; j++){
                x[i][j] = i * j;
            }
        }
        for (int i = 0; i < i * i; i++){
        }
        int k = 8;
        for (int i = 0; i < k * k; i++){
        }
    }
}
