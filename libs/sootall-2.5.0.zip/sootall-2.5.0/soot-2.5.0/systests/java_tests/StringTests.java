public class StringTests{

    public static void main (String [] args) {
    
            int i = 0;
            System.out.println("Number: "+i);

            String result = new String();

            result += i;

            System.out.println(result);
    }
    
}
