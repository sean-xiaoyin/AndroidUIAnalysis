public class RelationalOps {

    public static void main(String [] args){
        int counterLocal = 8;
        if (counterLocal <= 0){
        
        }
    }
}
