public class IntToChar {

    public static void main(String [] args){
        int x = 7;
        char c = (char)x;
        System.out.println(c);
    }
}
