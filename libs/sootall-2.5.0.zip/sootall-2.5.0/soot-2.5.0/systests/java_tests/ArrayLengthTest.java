public class ArrayLengthTest {
    
    public static void main (String [] args) {
        if (args.length != 1) {
            System.out.println("please give arg");
        }
    }
}
