public class PrimTypesTest {

    public static void main(String [] args) {
        long l = 21389127389123L;
        System.out.println("Test System Time: "+(l/1000.0));
    }
}
