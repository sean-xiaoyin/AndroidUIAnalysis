public class AssignCondition {

    public static void main (String [] args) {
    
        long l1 = 4L;
        long res = 5L;

        boolean ok = res == l1;
    }
}
