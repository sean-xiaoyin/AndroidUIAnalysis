public class ArrayInitEmpty {

    public static void main(String [] args) {
    
        int [] i = {};
    }
}
