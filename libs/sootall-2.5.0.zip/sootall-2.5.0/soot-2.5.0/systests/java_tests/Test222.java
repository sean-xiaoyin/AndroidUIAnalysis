public class Test222 {
    public static void main(String[] args) {
        String tmp = null + "";
    }
}

