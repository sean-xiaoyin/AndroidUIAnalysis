public class LineTest {

    void bar(){}
    void foo(){}

    public static void main(String [] args){
    }
}
