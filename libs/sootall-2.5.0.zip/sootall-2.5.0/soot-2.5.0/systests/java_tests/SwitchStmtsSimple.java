public class SwitchStmtsSimple {
    public static void main (String [] args) {
        //for (int i = 0 ; i < 10; i++) {
        int i = 7;
        switch (i) {
            
                case 2 : {
                             System.out.println("Hello");
                             break;
                             }
                case 7 : {
                               System.out.println("Hi");
                               break;
                             }
                default: {
                            System.out.println("Smile");
                            break;
                         }
            }
                
        //}
    }
}
