public class DoubleToShort {

    public static void main(String[] args) {
        double x = 9876543210.0;
        short y = (short)x;
        System.out.println(y);
        short s = 9876;
        double d = (double)s;
        System.out.println(d);
    }
}

