public class NewArray2 {

    public static void main(String [] args) {
        int [] i = new int[4];
        int x = 4;
    }
        
}
