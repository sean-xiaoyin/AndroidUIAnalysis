public class MyBlock {

    public static void main(String [] args){
        {
            int i = 0;
            System.out.println(i);
        }
        {
            int i = 9;
            System.out.println(i);
        }
        int i = 8;
        System.out.println(i);
    }
}
