public class Test95 {
    public Object o = new Object () { public void run(){}};

    public static void main(String [] args){
        
    }
}
