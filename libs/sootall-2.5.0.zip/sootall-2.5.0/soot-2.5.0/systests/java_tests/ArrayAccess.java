public class ArrayAccess {
    public static void main(String [] args){
        int [] arr = new int [] {3, 4, 2, 1};
        System.out.println(arr[3]);
    }
}
