public class NewStmt {
    public static void main(String [] args){
        NewStmt ns;
        ns = new NewStmt();

        new NewStmt();
    }
}
