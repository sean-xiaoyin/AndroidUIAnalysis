public class TestBackdoor {
    public static void main(String[] args) {
        char f = 'f';
        char g = f;
        for (char c = 'A'; c <= 'D'; c++) {
            System.out.println(c);
        }
    }
}

