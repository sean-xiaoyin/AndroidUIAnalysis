public class CaseUnorder {
    public static void main(String [] args) {
        
        int i = 0;

        switch (i) {
        
            case 3: i++;
            case 1: i--;
            case 10: i++;
        }
    }
}
