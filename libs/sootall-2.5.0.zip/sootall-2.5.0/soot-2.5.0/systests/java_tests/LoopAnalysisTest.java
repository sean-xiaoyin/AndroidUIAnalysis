public class LoopAnalysisTest {

    public static void main(String [] agrs){
        int i = 1;
        do {
            if (i == 1) break;
            System.out.println(i);
            System.out.println(i);
            System.out.println(i);
            System.out.println(i);
            System.out.println(i);
            System.out.println(i);
        }while(true);   
    }
}
