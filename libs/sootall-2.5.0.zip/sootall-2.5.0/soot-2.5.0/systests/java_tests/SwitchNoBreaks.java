public class SwitchNoBreaks {

    public static void main (String [] args) {
    
            int i = 1;
            switch (i) {
            
                case 1: System.out.println("Smile");
                case 2: System.out.println("Today");
            }
    }
}
