public class SimpleIfTest {

    public static void main(String [] args) {
        SimpleIfTest s = new SimpleIfTest();
    }
    
    public SimpleIfTest () {
        int x = 9;
        int y = 8;

        if (x <= y) {
            x = x + 1;
        }
    }
}
