public class JasminTest {

    public static void main(String [] args){
        int x = 9;
        System.out.println(x);
    }
}
