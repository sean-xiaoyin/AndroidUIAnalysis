public class LongInit {
    public long number = 3;

    public static void main(String [] args){
        LongInit li = new LongInit();
        System.out.println(li.number);
    }
}
