public class PrimClassLit {

    public static void main(String [] args){
        Class c = boolean.class;
        Class c1 = boolean[].class;
        Class c2 = int[].class;
        Class c3 = float[].class;
        Class c4 = byte[].class;
        Class c5 = double[].class;
        Class c6 = long[].class;
        Class c7 = short[].class;
        Class c9 = char.class;
        Class c22 = int.class;
        Class c32 = float.class;
        Class c42 = byte.class;
        Class c52 = double.class;
        Class c62 = long.class;
        Class c72 = short.class;
        Class c92 = char[].class;
        Class c10 = Object[].class;
        Class c11 = Object.class;
        Class c12 = Object[][][].class;
        Class c13 = boolean[][].class;
        Class c14 = long[][][][][].class;
    }
}
