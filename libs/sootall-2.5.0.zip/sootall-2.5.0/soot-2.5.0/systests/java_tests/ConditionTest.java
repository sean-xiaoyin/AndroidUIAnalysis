public class ConditionTest {

    public static void main (String [] args) {
        int i = 9;
        String out = (i < 10) ? "Big" : "Little";
        System.out.println(out);
    }
}
