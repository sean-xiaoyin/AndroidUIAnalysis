public class ArrayInitComp {

    public static void main(String [] args) {
    
        short s = 1;
        int [] a = { s, 1};
    }
}
