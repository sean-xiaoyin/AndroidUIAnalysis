public class InterfaceTest {
    public static void main(String [] args) {
        System.out.println(1 & 0x0200);
        System.out.println(17 & 0x0200);
    }
}
