public class EmptyCase {

    public static void main (String [] args) {
        String test = "jr47wwey5";
        for (int i = 0; i < test.length(); i++) {
        
            char c = test.charAt(i);
            switch(c){
            
                case 'j': {System.out.println("Smile"); break;}
                case '7': {System.out.println("Happy"); break;}
                case '4':
                case '5':

            }
        }
    }
}
