public class ShiftOps {
    
    public static void main(String [] args){
        long l = 2;
        l = l >> 1;
        System.out.println("l: "+l);
        l = 2;
        l = l << 1;
        System.out.println("l: "+l);
        l = 2;
        l = l >>> 1;
        System.out.println("l: "+l);
        
        l = 2L;
        l = l >> 1;
        System.out.println("l: "+l);
        l = 2L;
        l = l << 1;
        System.out.println("l: "+l);
        l = 2L;
        l = l >>> 1;
        System.out.println("l: "+l);
        
        
    }
}
