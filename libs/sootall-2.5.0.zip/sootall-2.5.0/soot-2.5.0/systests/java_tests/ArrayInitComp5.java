public class ArrayInitComp5 {

    public static void main(String [] args) {
    
        Object [] a = {  null};
    }
}
