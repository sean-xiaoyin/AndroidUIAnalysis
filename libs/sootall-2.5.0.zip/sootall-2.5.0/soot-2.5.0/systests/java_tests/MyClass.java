public class MyClass {
    public static double compute (double x){
        double z;
        x = Math.sin(x);
        z = x;
        return z;
 
    }
    public static void main(String [] args){
        compute(4.4);
    }
}

