public class NewArrayInit {

    public static void main(String [] args) {
        int [] a = new int [] { 1, 2, 3};
    }
}
