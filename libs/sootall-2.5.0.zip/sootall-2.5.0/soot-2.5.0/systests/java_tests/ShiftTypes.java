public class ShiftTypes {

    public static void main(String [] args){
        
    }
    
    public void run(){
    
        long k  = 9;
        k >>= 1;
    }
}   
