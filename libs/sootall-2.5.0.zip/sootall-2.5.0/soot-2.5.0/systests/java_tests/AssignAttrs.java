public class AssignAttrs {

    public static void main (String [] args){
        
        int i = 9;
        int j = 8;
        i += i;
        i -= j;
        i *= i;
        i /= j;
        i ^= j;
        i &= j;
        i |= i;
        i %= j;
        i >>= j;
        i <<= i;
        i >>>= j;


    }
}
