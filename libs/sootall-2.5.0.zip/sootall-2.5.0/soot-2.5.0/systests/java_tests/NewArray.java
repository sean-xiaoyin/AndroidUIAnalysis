public class NewArray {

    public static void main(String [] args) {
        int [] i = new int[4];
        int [][] j = new int[7][8];
    }
        
}
