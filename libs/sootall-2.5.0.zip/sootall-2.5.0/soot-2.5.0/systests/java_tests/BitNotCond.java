public class BitNotCond {

    public static void main(String [] args){
    
        int x = 9;
        int y = 10;

        boolean b = !(x > y);

        int b2 = ~x;
    }
}
