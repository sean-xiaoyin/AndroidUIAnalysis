import java.util.*;

public class IteratorTest {
    

    public static void main(String [] args){
    
    }

    public void run(){
    
        List l = new ArrayList();
        l.add("j");
        l.add("e");
        l.add("l");
        
        Iterator it = l.iterator();
        while (it.hasNext()){
            
        }
    }
}
