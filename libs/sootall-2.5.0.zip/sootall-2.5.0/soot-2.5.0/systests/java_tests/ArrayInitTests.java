public class ArrayInitTests {

    public static void main(String [] args) {
        ArrayInitTests a = new ArrayInitTests();
        a.run();
    }

    private void run() {
    
        int i = 0;

        int [] a = {2,34,5};

        int [] b = { 2,
            3,
            4,
            i};

        int c [] = { 2, 8};
    }
}
