public class Compare3 {
    public static void main(String [] args) {
    
        Compare3 c = new Compare3();
        c.run();
    }

    private void run() {
        int i = 9;
        long l = 10L;
        double d = 0.98F;

        float f = 19L;
        /*if (l >= i) {
            System.out.println(l);
        }
        else if (l < i) {
            System.out.println(i);
        }*/


        long j = i + l;
        /*float f = 0.978213F;
        double d = 0.9;

        if (d == f) {
            d += f;
        }*/
    }
}
