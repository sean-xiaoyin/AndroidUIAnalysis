class Simple {
    public Simple () {
        System.out.println("Smile");
    }
}
public class SimpleChild extends Simple {
    public static void main(String[] args) { int i = 9; }
    
    public SimpleChild() { super(); }
}
