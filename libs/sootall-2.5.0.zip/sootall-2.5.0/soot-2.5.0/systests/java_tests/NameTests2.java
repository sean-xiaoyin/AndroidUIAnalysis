public class NameTests2 {

    public static void main(String [] args) {
        //int NameTests2;
        NameTests2 nt = new NameTests2();
    }
}
