public class SwitchOrderTest2 {

    public static void main (String [] args) {
        int i = 9;
        switch(i){
            case 2: System.out.println("2");
            case 1: System.out.println("1");
            case 3: System.out.println("3");
        }
    }
}
