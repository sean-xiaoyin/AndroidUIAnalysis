public class EmptyAfterField {

    public int x = 9;;

    public static void main(String [] args){
    }
}
