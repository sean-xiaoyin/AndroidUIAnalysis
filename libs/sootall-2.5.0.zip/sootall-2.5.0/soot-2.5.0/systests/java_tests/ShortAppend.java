public class ShortAppend {

    public static void main (String [] args) {
    
        short s = 9;
        System.out.println("s: "+s);
    }
}
