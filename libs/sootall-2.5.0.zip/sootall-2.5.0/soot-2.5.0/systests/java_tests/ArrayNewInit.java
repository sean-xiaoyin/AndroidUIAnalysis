public class ArrayNewInit {

    public static void main(String [] args) {
    
        int [] a = new int[3];
        int [] b [] = new int [4][5];

        int [][] c = new int[3][];

        int [] e = new int [] { 1,2, 3,4};
        int f [][] = new int[][]{{1,2},{3,4},{5,6}};

        int g [][] = new int [][]{new int[3], new int[4]};
    }
}
