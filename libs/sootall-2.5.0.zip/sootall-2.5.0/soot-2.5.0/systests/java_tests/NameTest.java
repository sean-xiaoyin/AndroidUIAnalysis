class NameTest {
    
    public static void main (String [] args ){
    }
}

class A {
}
