public class IfTest2 {

    public static void main(String [] args){
        int x = 9;
        if (x == 8) {
            x = x + 1;
        }
    }
}
