public class LocalDecl {
    
    public static void main(String [] args){
        String s = new String("j");
    }
}
