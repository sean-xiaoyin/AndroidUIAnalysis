public class SwitchNoDefault {

    public static void main (String [] args) {
    
            int i = 9;

            switch (i) {
            
                case 1: {
                            System.out.println("9==1");
                        }
                case 9: {
                            System.out.println("9==9");
                        }
            }
    }
}
