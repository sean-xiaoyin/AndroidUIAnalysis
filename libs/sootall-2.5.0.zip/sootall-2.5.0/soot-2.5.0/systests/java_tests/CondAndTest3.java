public class CondAndTest3 {

    public static void main(String [] args){
    
        boolean y = true;
        if (false && y){
            boolean x = true;
        }
    }
}
