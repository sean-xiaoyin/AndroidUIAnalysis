public class LongToChar {

    public static void main(String[] args) {
        long x = 9876543210L;
        char y = (char)x;
        System.out.println(y);
    }
}

