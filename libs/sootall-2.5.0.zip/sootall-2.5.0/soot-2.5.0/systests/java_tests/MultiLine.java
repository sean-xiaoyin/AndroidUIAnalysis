public class MultiLine {
    
    public static void main(String [] args){
        int i = 9;
        int j = 8;
        int k = 8;
        int l = 7;
        int h = 4;

        i = j + k - l - h;
    }
}
