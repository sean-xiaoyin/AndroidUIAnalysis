public class CastTest {

    public static void main(String [] args){
        double d = (double)(double) 1+0;

        Object m = new Integer(8);
        Integer x = (Integer)m;
    }
}   
