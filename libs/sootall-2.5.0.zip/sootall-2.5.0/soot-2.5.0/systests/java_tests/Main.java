public class Main {
      public static void main (String args[])
      { Object[] myargs = new Object[3];
        //System.out.println("myargs are " + myargs);
      }
}

