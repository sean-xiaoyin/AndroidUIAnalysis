public class Binary {

    public static void main(String [] args) {
        int i = 0;
        int j = 1;
        int k = 2;
        int m = 6;
        
        j = k + i;
        j = k - i;

        j = k * k;

        j = m / k;

        j = k + i + m;

        j = k * i + m;
         
        j = m + i - k;

        j = i + i + k + k;

        j = i * i - k * k;

    }
}
