public class SimpleCharOp {

    public static void main(String [] args){
        System.out.println(""+Character.MAX_VALUE);
    }
}
