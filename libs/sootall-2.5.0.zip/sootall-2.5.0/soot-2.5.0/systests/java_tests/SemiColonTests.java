public class SemiColonTests {


    static String x = "J";;

    public static void main(String [] args){
        System.out.println(x+x+x);
    }
}
