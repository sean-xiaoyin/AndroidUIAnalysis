public class DefUse {

    public static void main(String [] args){
        int i;
        int j;

        i = 9;
        j = i;
        
    }
}
