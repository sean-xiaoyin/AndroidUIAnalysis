public class ArrayInitComma {

    public static void main(String [] args) {
    
        int [] a = {,};
    }
}
