public class UnreachableFields {

    private int x;
    private Object y;

    public static void main(String [] args){
        
    }
}
