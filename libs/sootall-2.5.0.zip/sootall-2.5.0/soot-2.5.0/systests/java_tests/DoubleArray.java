public class DoubleArray {
    
    public static void main(String [] args){
        double [][]m = {{1, 2, 3}, {2, 5, 6}, {3, 6, 9}};

        System.out.println(m[0][0]);
    }
}
