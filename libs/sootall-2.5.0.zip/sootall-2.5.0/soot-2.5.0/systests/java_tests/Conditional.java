public class Conditional {

    public static void main(String [] args){
        int x = 9;
        int y = 3;

        int z = (x > y) ? x  : y;

        System.out.println(x);
        System.out.println(y);
        System.out.println(z);
    }
}
