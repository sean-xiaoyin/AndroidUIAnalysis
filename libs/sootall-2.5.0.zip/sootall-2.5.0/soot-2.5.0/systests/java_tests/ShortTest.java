public class ShortTest {

    public static void main (String [] args) {
   
        ShortTest st = new ShortTest();
        System.out.println(st.go(1,3));
    }
    protected final short go(int i, int j) {
        return 0;
    }
}
