public class StringConcatInts {

    public static void main(String[] args) {

        System.out.println("Should be ten: " + (9+1));
        System.out.println("Should be nintyone: " + 9+1);

        int i = 9;
        System.out.println("Should be ten: "+ (i+1));
    }

}
