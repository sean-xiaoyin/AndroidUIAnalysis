public class LitTest {

    public static void main(String [] args) {
    
        int i = 0;
        double j = 0.9;
        char x = 'c';
        byte b = 8;
        short s = 9;
        long l = 10000;
        float f = 0.99F;
        String st = "this";
    }
}
