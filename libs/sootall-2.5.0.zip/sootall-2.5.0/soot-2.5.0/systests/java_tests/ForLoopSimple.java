public class ForLoopSimple {
    public static void main(String [] args){
        int j = 9;
        
        for (int i = 0; i < 10; i++){
            j = j*i;
        }
    }
}
