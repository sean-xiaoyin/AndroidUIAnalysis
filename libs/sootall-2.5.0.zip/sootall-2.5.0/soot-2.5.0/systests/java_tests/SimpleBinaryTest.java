
public class SimpleBinaryTest {
    public static void main(String[] args) {
        int i = 0;
        int j = 1;
        int k = 2;
        int m = 4;
        int n = 3;
        i = j + k;
        i = k - j;
        i = k * m;
        i = m / k;
        i = m % n;
        i = j + k * m - n;
    }
    
    public SimpleBinaryTest() { super(); }
}
