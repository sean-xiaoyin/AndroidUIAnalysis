public class PrimClassLit2 {

    public static void main(String [] args){
        Class c10 = Object[].class;
    }
}
