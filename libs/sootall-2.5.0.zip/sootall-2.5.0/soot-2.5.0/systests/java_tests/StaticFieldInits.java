public class StaticFieldInits {
    
    static int i = 9;

    public static void main(String [] args){
        System.out.println(i);
    }
}
